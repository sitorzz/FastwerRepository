<?php

session_start();

$id_session=$_SESSION["id"];

@$id_pregunta = $_SESSION["pregunta"];


?>