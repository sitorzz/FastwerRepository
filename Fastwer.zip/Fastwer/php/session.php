<?php

session_start();

$id_session=$_SESSION["id"];

?>