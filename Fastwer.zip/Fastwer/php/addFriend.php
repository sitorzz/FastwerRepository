<?php

$identificador = $_GET['name']; 

echo '<h>'.$identificador.'</h>'; 

?>