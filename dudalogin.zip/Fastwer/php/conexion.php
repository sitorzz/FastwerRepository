<?php

$host="localhost";
$user="root";
$password="root";
$db="fastwer";
$con = new mysqli($host,$user,$password,$db);

echo "conecta";
?>